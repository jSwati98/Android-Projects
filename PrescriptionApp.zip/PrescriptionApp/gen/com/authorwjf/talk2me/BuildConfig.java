/** Automatically generated file. DO NOT MODIFY */
package com.authorwjf.talk2me;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}